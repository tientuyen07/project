package com.example.administrator.mqtt;

import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {
    MqttHelper mqttHelper;
    private GoogleMap mMap;
    //    TextView dataReceived;
    Double lati = 0.0;
    Double longi = 0.0;
    Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = MainActivity.this;
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
//        dataReceived = (TextView) findViewById(R.id.dataReceived);
        mapFragment.getMapAsync(this);

        startMqtt();
    }

    private void startMqtt() {
        Log.i("DEBUG", "Start MQTT!!!!!!!!");
        mqttHelper = new MqttHelper(getApplicationContext());
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
                Log.i("DEBUG", "Connected!!");
            }

            @Override
            public void connectionLost(Throwable throwable) {
                Log.i("DEBUG", "Not connect!!!!!!!!");
            }

            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                Log.i("Debug", mqttMessage.toString());
                String long_lat = mqttMessage.toString();
                String _long = "";
                String _lat = "";
                int vtri = 0;
                for (int i = 0; i < long_lat.length(); i++) {
                    if (long_lat.charAt(i) == ',') {
                        vtri = i;
                    }
                }
                for (int i = 0; i < vtri; i++) {
                    if (i == 2) {
                        _lat = _lat + '.';
                    }
                    _lat = _lat + long_lat.charAt(i);
                }
                for (int i = vtri + 1; i < long_lat.length(); i++) {
                    if (i == vtri + 4) {
                        _long = _long + '.';
                    }
                    _long = _long + long_lat.charAt(i);
                }
                lati = Double.parseDouble(_lat);
                longi = Double.parseDouble(_long);
                Log.i("DEBUG", lati + " " + longi);
//                dataReceived.setText(mqttMessage.toString());
//                mMap.clear();
                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                mMap.getUiSettings().setZoomControlsEnabled(true);
                Toast.makeText(mContext, "Vị trí:    " + lati + "  " + longi, Toast.LENGTH_SHORT).show();
                LatLng vitri = new LatLng(lati, longi);

                mMap.addMarker(new MarkerOptions().position(vitri).title("Vị trí xe!!!!!"));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(vitri, 18));

//                dataReceived.setText(mqttMessage.toString());
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {

            }
        });
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        Log.i("DEBUG", lati + " " + longi);
//        LatLng vitri = new LatLng(lati, longi);
////                mMap.addMarker(new MarkerOptions().position(vitri).title("Vị trí xe!!!!!"));
////                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(vitri, 18));
////                dataReceived.setText(mqttMessage.toString());
//
//        // Add a marker in Sydney and move the camera
////        LatLng vitri = new LatLng(21.112782, 105.835768);
//        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
//        mMap.getUiSettings().setZoomControlsEnabled(true);
//        mMap.addMarker(new MarkerOptions().position(vitri).title("Vị trí nhà thằng cc Tùng!!!!!"));
//        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(vitri, 18));
    }
}